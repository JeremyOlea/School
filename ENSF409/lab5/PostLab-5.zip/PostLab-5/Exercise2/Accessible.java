public interface Accessible {
    public String getName();
    public void setName(String newName);
}