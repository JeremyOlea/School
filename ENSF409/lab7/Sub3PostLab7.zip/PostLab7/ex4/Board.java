
/**
 * 3 by 3 Tic-Tac-Toe board
 * @author M. Moshirpour, Michael Jeremy Olea
 * @version 1.0
 * @since March 24th, 2019
 */
public class Board implements Constants {
	/**
	 * 2D array used for X's and O's of game
	 */
	private char theBoard[][];
	/**
	 * Number of spaces filled by an X or an O
	 */
	private int markCount;

	/**
	 * Constructor for empty 3 by 3 Board
	 */
	public Board() {
		markCount = 0;
		theBoard = new char[3][];
		for (int i = 0; i < 3; i++) {
			theBoard[i] = new char[3];
			for (int j = 0; j < 3; j++)
				theBoard[i][j] = SPACE_CHAR;
		}
	}
	
	/**
	 * Returns the Mark of a certain row and column
	 * @param row the row of the desired position
	 * @param col the column of the desired position
	 * @return the Mark on that is on the desired position
	 */
	public char getMark(int row, int col) {
		return theBoard[row][col];
	}

	/**
	 * Checks if board is full
	 * @return true if the board is full, false if board is not full
	 */
	public boolean isFull() {
		return markCount == 9;
	}

	/**
	 * Checks if player x wins
	 * @return whether player x has won or not
	 */
	public boolean xWins() {
		if (checkWinner(LETTER_X) == 1)
			return true;
		else
			return false;
	}

	/**
	 * Checks if player o wins
	 * @return whether player o has won or not
	 */
	public boolean oWins() {
		if (checkWinner(LETTER_O) == 1)
			return true;
		else
			return false;
	}

	/**
	 * Displays current state of the board onto command line
	 */
	public String display() {
		String b = "BOARD\n";
		b += displayColumnHeaders();
		b += addHyphens();
		for (int row = 0; row < 3; row++) {
			addSpaces();
			b += "    row " + row + ' ';
			for (int col = 0; col < 3; col++)
				b += "|  " + getMark(row, col) + "  ";
			b += "|\n";
			b += addSpaces();
			b += addHyphens();
		}
		b += " \0";
		return b;
	}

	/**
	 * Places a Mark at the desired position
	 * @param row row of desired position
	 * @param col column of desired position
	 * @param mark the mark that will be placed at the desired position
	 */
	public void addMark(int row, int col, char mark) {
		
		theBoard[row][col] = mark;
		markCount++;
	}

	/**
	 * Clears all marks on the board
	 */
	public void clear() {
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				theBoard[i][j] = SPACE_CHAR;
		markCount = 0;
	}

	/**
	 * Checks if a player has won the game
	 * @param mark the character representing the winner of the game
	 * @return result of if winner was found
	 */
	int checkWinner(char mark) {
		int row, col;
		int result = 0;

		for (row = 0; result == 0 && row < 3; row++) {
			int row_result = 1;
			for (col = 0; row_result == 1 && col < 3; col++)
				if (theBoard[row][col] != mark)
					row_result = 0;
			if (row_result != 0)
				result = 1;
		}

		
		for (col = 0; result == 0 && col < 3; col++) {
			int col_result = 1;
			for (row = 0; col_result != 0 && row < 3; row++)
				if (theBoard[row][col] != mark)
					col_result = 0;
			if (col_result != 0)
				result = 1;
		}

		if (result == 0) {
			int diag1Result = 1;
			for (row = 0; diag1Result != 0 && row < 3; row++)
				if (theBoard[row][row] != mark)
					diag1Result = 0;
			if (diag1Result != 0)
				result = 1;
		}
		if (result == 0) {
			int diag2Result = 1;
			for (row = 0; diag2Result != 0 && row < 3; row++)
				if (theBoard[row][3 - 1 - row] != mark)
					diag2Result = 0;
			if (diag2Result != 0)
				result = 1;
		}
		return result;
	}

	/**
	 * Displays the numbers of each column
	 */
	String displayColumnHeaders() {
		String b = "          ";
		for (int j = 0; j < 3; j++)
			b += "|col " + j;
		b += " \n";
		return b;
	}

	/**
	 * Prints out the hyphens that make up the board
	 */
	String addHyphens() {
		String b = "          ";
		for (int j = 0; j < 3; j++)
			b += "+-----";
		b += "+\n";
		return b;
	}

	/**
	 * Prints out the spaces used for the board
	 */
	String addSpaces() {
		String b = "          ";
		for (int j = 0; j < 3; j++)
			b += "|     ";
		b += "|\n";
		return b;
	}
}
